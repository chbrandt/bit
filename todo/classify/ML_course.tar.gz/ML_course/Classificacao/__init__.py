from RegressaoLogistica import RegressaoLogistica as RegLog;
from NewtonRaphson import NewtonRaphson as NR;
